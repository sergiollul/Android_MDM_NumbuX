# app_lock_flutter

app_lock_flutter

- This is a applock application based on flutter and it is only for Android.
- app_lock_flutter depends on method channels to trigger background services in MainActivity.kt, also uses Getx state management.
- it uses USAGE_STATS to trigger application activities.


<!-- ![Screenshot_20221231-135028](https://user-images.githubusercontent.com/56929825/210130743-d30f5155-3b4e-4d49-9c73-718f20901592.jpg | width=100) -->
<!-- ![Screenshot_20221231-135034](https://user-images.githubusercontent.com/56929825/210130744-7f2e208a-5447-49c8-bc35-1c6ccfe48a48.jpg | width=100) -->
<!-- ![Screenshot_20221231-135042](https://user-images.githubusercontent.com/56929825/210130749-59f770c6-2304-489b-b56f-3533b8baa39d.jpg | width=100) -->
<!-- ![Screenshot_20221231-135140](https://user-images.githubusercontent.com/56929825/210130753-61431b86-5d3a-4909-88c9-0ebb16e2b1cf.jpg | width=100) -->
<!-- ![Screenshot_20221231-135047](https://user-images.githubusercontent.com/56929825/210130756-4498aabd-cf84-4bc6-a777-64323f732d33.jpg | width=100) -->

<img src="https://user-images.githubusercontent.com/56929825/210130743-d30f5155-3b4e-4d49-9c73-718f20901592.jpg" width="150" height="320"> <img src="https://user-images.githubusercontent.com/56929825/210130744-7f2e208a-5447-49c8-bc35-1c6ccfe48a48.jpg" width="150" height="320"> 
<img src="https://user-images.githubusercontent.com/56929825/210130749-59f770c6-2304-489b-b56f-3533b8baa39d.jpg" width="150" height="320">
<img src="https://user-images.githubusercontent.com/56929825/210130753-61431b86-5d3a-4909-88c9-0ebb16e2b1cf.jpg" width="150" height="320">
<img src="https://user-images.githubusercontent.com/56929825/210130756-4498aabd-cf84-4bc6-a777-64323f732d33.jpg" width="150" height="320">



https://user-images.githubusercontent.com/56929825/210130784-6cc095a8-af96-4ce6-a5db-025b91e4e45c.mp4

